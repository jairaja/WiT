import React, { useState, useEffect, useId } from "react";
import "./userInputForm.scss";
import ulsterBankLogo from "../images/ulster-bank-logo.png";
import rbsLogo from "../images/rbs-logo.png";
import couttsLogo from "../images/coutts-logo.png";
import lombardLogo from "../images/lombard-logo.png";
import natwestLogo from "../images/natwest-bank-logo.png";

type UserInputFormProps = {};
type CustomerInputValuesTypes = {
  selectedBank: string;
  customerName: string;
  customerMobileNumber?: number;
  customerAccountNumber?: number;
  customerSortCode?: number;
};
type ErrorTypes = {
  customerNameError?: string;
  customerMobileNumberError?: string;
  customerAccountNumberError?: string;
  customerSortCodeError?: string;
};

const UserInputForm: React.FC<UserInputFormProps> = () => {
  // const [selectedBank, setSelectedBank] = useState(natwestLogo);

  const [customerInputValues, setCustomerInputValues] =
    useState<CustomerInputValuesTypes>({
      selectedBank: natwestLogo,
      customerName: "",
      customerMobileNumber: undefined,
      customerAccountNumber: undefined,
      customerSortCode: undefined,
    });

  const validateContactNumber = new RegExp(/^\d{10,10}$/);

  const [allBanks, setAllBanks] = useState({});
  const [errors, setErrors] = useState<ErrorTypes>({
    customerNameError: undefined,
    customerMobileNumberError: undefined,
    customerAccountNumberError: undefined,
    customerSortCodeError: undefined,
  });
  const [submitting, setSubmitting] = useState(false);
  const bankSelectId = useId();

  const fetchBankList = async () => {
    await fetch("http://localhost:3001/api/brands").then((sucess) => {
      sucess.json().then((data) => setAllBanks(data));
    });
  };

  const validateValues = (inputValues: CustomerInputValuesTypes) => {
    const errors: ErrorTypes = {};
    if (customerInputValues.customerName.length < 1) {
      errors.customerNameError = "Name field can not be blank. ";
    }
    if (!customerInputValues.customerMobileNumber) {
      errors.customerMobileNumberError =
        "Mobile Number field can not be blank. ";
    } else if (customerInputValues.customerMobileNumber) {
      if (
        !validateContactNumber.test(
          customerInputValues.customerMobileNumber.toString()
        )
      ) {
        errors.customerMobileNumberError =
          "Mobile number should contain 10 digits. ";
      }
    }
    if (
      customerInputValues.customerAccountNumber &&
      customerInputValues.customerAccountNumber?.toString()?.length < 10
    ) {
      errors.customerAccountNumberError = "Invalid Account Number. ";
    }
    if (customerInputValues.customerSortCode?.toString().length !== 6) {
      errors.customerSortCodeError = "Invalid Sort Code. ";
    }
    return errors;
  };

  useEffect(() => {
    fetchBankList();
  }, []);

  const bankSelected = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedBankValue = event?.target?.value;

    switch (selectedBankValue) {
      case "ulster":
        // setSelectedBank(ulsterBankLogo);
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: ulsterBankLogo,
        });
        break;
      case "lombard":
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: lombardLogo,
        });

        break;
      case "coutts":
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: couttsLogo,
        });

        break;
      case "rbs":
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: rbsLogo,
        });

        break;
      case "nwb":
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: natwestLogo,
        });

        break;
      default:
        setCustomerInputValues({
          ...customerInputValues,
          selectedBank: natwestLogo,
        });
    }
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCustomerInputValues({
      ...customerInputValues,
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = (event: any) => {
    event.preventDefault();
    setErrors(validateValues(customerInputValues));
    setSubmitting(true);
  };

  const finishSubmit = () => {
    console.log(customerInputValues);
  };

  useEffect(() => {
    if (Object.keys(errors).length === 0 && submitting) {
      finishSubmit();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [errors]);

  const errorOrSuccessMessage = () => {
    return (
      <>
        {Object.keys(errors).length === 0 && submitting ? (
          <span className="SucessMessage">Successfully submitted</span>
        ) : null}

        {Object.keys(errors).length !== 0 && submitting ? (
          <span className="ErrorMessage">{JSON.stringify(errors)}</span>
        ) : null}
      </>
    );
  };

  return (
    <>
      {errorOrSuccessMessage()}
      <form className="UserInputForm" onSubmit={handleSubmit}>
        <fieldset>
          <div className="InputFieldSection">
            <label htmlFor={bankSelectId} className="FormLabels">
              Choose Bank:
            </label>
            <select
              id={bankSelectId}
              className="FormInput"
              onChange={bankSelected}
            >
              {Array.isArray(allBanks) &&
                allBanks.map((bank) => {
                  return (
                    <option key={bank.id} value={bank.id}>
                      {bank.name}
                    </option>
                  );
                })}
            </select>
            <img
              src={customerInputValues.selectedBank}
              className="SelectedBankLogo"
              alt="SelectedBankLogo"
            />
          </div>
          <br />
          <div className="InputFieldSection">
            <label className="FormLabels">Name:</label>
            <input
              type="text"
              name="customerName"
              value={customerInputValues.customerName}
              onChange={handleChange}
            />
          </div>
          <br />
          <div className="InputFieldSection">
            <label className="FormLabels">Contact Number:</label>
            <input
              type="text"
              name="customerMobileNumber"
              value={customerInputValues.customerMobileNumber}
              onChange={handleChange}
            />
          </div>
          <br />
          <div className="InputFieldSection">
            <label className="FormLabels">Account Number:</label>
            <input
              type="text"
              name="customerAccountNumber"
              value={customerInputValues.customerAccountNumber}
              onChange={handleChange}
            />
          </div>
          <br />
          <div className="InputFieldSection">
            <label className="FormLabels">Sort Code:</label>
            <input
              type="text"
              name="customerSortCode"
              value={customerInputValues.customerSortCode}
              onChange={handleChange}
            />
          </div>
          <br />
          <button type="submit">Submit</button>
        </fieldset>
      </form>
    </>
  );
};

export default UserInputForm;
