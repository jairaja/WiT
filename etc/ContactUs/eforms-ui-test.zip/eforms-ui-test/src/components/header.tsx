import React from "react";
import "./header.scss";
import natwestGroupLogo from "../images/natwest-group-logo.png";

type headerProps = {};

const Header: React.FC<headerProps> = () => {
  return (
    <header className="Header">
      <img src={natwestGroupLogo} alt="Natwest Logo" className="Logo" />
    </header>
  );
};

export default Header;
