import React from "react";
import "./App.scss";
import Header from "./components/header";
import UserInputForm from "./components/userInputForm";

const App: React.FC = () => {
  return (
    <div className="App">
      <Header />
      <UserInputForm />
    </div>
  );
};

export default App;
