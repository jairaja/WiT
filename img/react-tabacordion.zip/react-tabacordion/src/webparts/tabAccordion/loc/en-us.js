define([], function() {
  return {
    "PropertyPaneDescription": "Customize your Tab Accordion",
    "BasicGroupName": "Tabs",
    "TitleFieldLabel": "Title",
    "ManageAccordion": "Manage Tabs",
    "Type": "Type",
    "Tabs": "Tabs",
  }
});