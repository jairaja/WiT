import Tabs from './Tabs';
import TabLink from './TabLink';
import TabContent from './TabContent';

export {
    Tabs,
    TabLink,
    TabContent
};